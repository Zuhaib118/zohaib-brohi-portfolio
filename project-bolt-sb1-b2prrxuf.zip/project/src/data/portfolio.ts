/**
 * ============================================================
 *  PORTFOLIO CONTENT — EDIT EVERYTHING HERE
 * ============================================================
 *  This is the single source of truth for all the text, links,
 *  images, projects, certificates, achievements and contact
 *  details shown on the website. Update a value here and it
 *  updates everywhere automatically.
 *
 *  NOTE: Never invent certificates, awards, client names, dates
 *  or performance metrics. Use the "TBD" placeholders until the
 *  real information is available.
 * ============================================================
 */

export const profile = {
  name: 'Zohaib Brohi',
  title: 'BSIT Student | Web Developer | Digital Marketer',
  tagline:
    'Turning ideas into digital experiences through technology, creativity and continuous learning.',
  // Replace with your own photo (place a file in /public or paste a URL)
  photo:
    'https://images.pexels.com/photos/26872232/pexels-photo-26872232.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  location: 'Shikarpur, Sindh, Pakistan',
  university: 'Shaikh Ayaz University, Shikarpur',
  resumeUrl: '', // Add a link to your resume file when ready (e.g. "/resume.pdf")
  about: [
    "I'm Zohaib Brohi, a BS Information Technology student at Shaikh Ayaz University with a growing passion for building things on the web. My focus sits at the intersection of web development and digital marketing — I love crafting clean, responsive websites and then making sure people actually find and enjoy them.",
    'Day to day, I sharpen my skills in HTML, CSS, JavaScript and responsive design, while also diving into SEO, social media marketing and Facebook Ads. I treat every project as a chance to learn something new and turn theory into real, working products.',
    'I believe growth comes from doing. Whether it is a university assignment, a freelance client project, or a personal experiment, I am always looking for practical challenges that push my skills forward and add real value for the people I work with.',
  ],
};

export const socials = {
  github: 'https://github.com/',
  linkedin: 'https://www.linkedin.com/',
  fiverr: 'https://www.fiverr.com/',
  email: 'mailto:your.email@example.com',
};

export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Education', href: '#education' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Certificates', href: '#certificates' },
  { label: 'Achievements', href: '#achievements' },
  { label: 'Experience', href: '#experience' },
  { label: 'Contact', href: '#contact' },
];

/* ---------------------------- EDUCATION ---------------------------- */

export interface EducationItem {
  degree: string;
  institution: string;
  period: string;
  current: string;
  projects: string[];
}

export const education: EducationItem[] = [
  {
    degree: 'BS Information Technology (BSIT)',
    institution: 'Shaikh Ayaz University, Shikarpur',
    period: 'Ongoing',
    current: 'Current semester / year — edit me',
    projects: [
      'AutoVerse — Car Showroom Website',
      'Zayka House — Restaurant Website',
      'TechNova — Electronics E-commerce Website',
      'EduConnect — Education Portal',
    ],
  },
  {
    degree: 'Intermediate (Pre-Engineering)',
    institution: 'Edit with your college name',
    period: 'Edit with study period',
    current: 'Completed',
    projects: ['Add a relevant academic project'],
  },
];

/* ---------------------------- SKILLS ---------------------------- */

export interface SkillCategory {
  title: string;
  icon: string; // lucide icon name
  skills: string[];
}

export const skillCategories: SkillCategory[] = [
  {
    title: 'Web Development',
    icon: 'Code2',
    skills: ['HTML', 'CSS', 'JavaScript', 'Responsive Design'],
  },
  {
    title: 'Digital Marketing',
    icon: 'TrendingUp',
    skills: ['SEO', 'Social Media Marketing', 'Facebook Ads'],
  },
  {
    title: 'Creative Tools',
    icon: 'Palette',
    skills: ['Canva', 'Graphic Design'],
  },
  {
    title: 'Other Skills',
    icon: 'Sparkles',
    skills: ['Add a skill', 'Add a skill'],
  },
];

/* ---------------------------- PROJECTS ---------------------------- */

export interface Project {
  title: string;
  subtitle: string;
  description: string;
  image: string;
  tech: string[];
  liveUrl: string;
  githubUrl: string;
}

export const projects: Project[] = [
  {
    title: 'AutoVerse',
    subtitle: "Zamil's Car Gallery — Car Showroom Website",
    description:
      'A modern car showroom website for browsing inventory, viewing detailed vehicle specs and enquiring about listings. Built with a clean, conversion-focused layout.',
    image:
      'https://images.pexels.com/photos/18108314/pexels-photo-18108314.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    tech: ['HTML', 'CSS', 'JavaScript', 'Responsive'],
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    title: 'Zayka House',
    subtitle: 'Zobro Restaurant — Restaurant Website',
    description:
      'A appetizing restaurant website featuring a menu, reservation flow and an inviting visual design that reflects the dining brand identity.',
    image:
      'https://images.pexels.com/photos/12181619/pexels-photo-12181619.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    tech: ['HTML', 'CSS', 'JavaScript', 'Responsive'],
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    title: 'TechNova',
    subtitle: 'Electronics E-commerce Website',
    description:
      'An electronics e-commerce storefront for browsing products, viewing details and a cart-ready shopping experience with a sleek tech aesthetic.',
    image:
      'https://images.pexels.com/photos/11297769/pexels-photo-11297769.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    tech: ['HTML', 'CSS', 'JavaScript', 'Responsive'],
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    title: 'EduConnect',
    subtitle: 'Education Portal',
    description:
      'An education portal designed to connect students with learning resources, course information and an easy-to-navigate academic experience.',
    image:
      'https://images.pexels.com/photos/5212666/pexels-photo-5212666.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    tech: ['HTML', 'CSS', 'JavaScript', 'Responsive'],
    liveUrl: '#',
    githubUrl: '#',
  },
];

/* --------------------------- CERTIFICATES -------------------------- */

export interface Certificate {
  title: string;
  organization: string;
  date: string;
  skills: string[];
  // Replace with a screenshot/preview of the actual certificate
  image: string;
  url: string; // Link to view / verify the certificate
}

export const certificates: Certificate[] = [
  {
    title: 'PITP Digital Marketing Course',
    organization: 'PITP',
    date: 'Add completion date',
    skills: ['Digital Marketing', 'SEO', 'Social Media Marketing'],
    image: '',
    url: '#',
  },
  {
    title: 'Certificate title — edit me',
    organization: 'Issuing organization — edit me',
    date: 'Completion date — edit me',
    skills: ['Skill one', 'Skill two'],
    image: '',
    url: '#',
  },
];

/* -------------------------- ACHIEVEMENTS --------------------------- */

export interface Achievement {
  title: string;
  description: string;
  date: string;
  image?: string;
}

export const achievements: Achievement[] = [
  {
    title: 'Achievement title — edit me',
    description: 'Describe the achievement, training milestone, presentation, competition or award.',
    date: 'Date — edit me',
  },
  {
    title: 'Verified freelance accomplishment — edit me',
    description: 'Describe a verified freelance result (no invented metrics).',
    date: 'Date — edit me',
  },
];

/* --------------------------- EXPERIENCE ---------------------------- */

export interface ExperienceItem {
  role: string;
  company: string;
  type: string;
  period: string;
  description: string;
  services: string[];
}

export const experience: ExperienceItem[] = [
  {
    role: 'Freelance Web Developer & Digital Marketer',
    company: 'Self Employed • Fiverr',
    type: 'Freelance',
    period: 'Edit with start date — Present',
    description:
      'Offering website design, responsive development, landing pages, SEO and digital marketing services to clients. Building modern, fast websites and helping businesses improve their online visibility.',
    services: [
      'Website Design',
      'Responsive Website Development',
      'Landing Page Creation',
      'SEO',
      'Digital Marketing',
    ],
  },
  {
    role: 'Graphic & Visual Designer',
    company: 'Self Employed • Freelance',
    type: 'Freelance',
    period: 'Jul 2024 - Oct 2024 • 3 mos',
    description:
      'Designed visual assets, brand identities and promotional materials for various digital platforms. Specialised in high-quality logos, social media graphics, banners and marketing visuals that communicate brand value and drive engagement.',
    services: ['Logo Design', 'Social Media Graphics', 'Banners', 'Brand Identity'],
  },
];

export const services = [
  {
    title: 'Website Design',
    description: 'Clean, modern, brand-aligned website designs crafted for a polished first impression.',
    icon: 'Layout',
  },
  {
    title: 'Responsive Development',
    description: 'Websites that look and work beautifully on mobile, tablet and desktop.',
    icon: 'Smartphone',
  },
  {
    title: 'Landing Page Creation',
    description: 'Focused, high-converting landing pages for campaigns, products and services.',
    icon: 'Rocket',
  },
  {
    title: 'SEO',
    description: 'On-page SEO improvements to help your site rank and get discovered.',
    icon: 'Search',
  },
  {
    title: 'Digital Marketing',
    description: 'Social media marketing and Facebook Ads to reach and grow your audience.',
    icon: 'Megaphone',
  },
];
