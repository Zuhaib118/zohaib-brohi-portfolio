import { useEffect, useState } from 'react';
import { navLinks, profile } from '@/data/portfolio';
import { Icon } from '@/components/Icon';

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('#home');

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const sections = navLinks.map((l) => l.href.slice(1));
      const current = sections.find((id) => {
        const el = document.getElementById(id);
        if (!el) return false;
        const rect = el.getBoundingClientRect();
        return rect.top <= 120 && rect.bottom >= 120;
      });
      if (current) setActive(`#${current}`);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const close = () => setOpen(false);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-navy/90 py-3 shadow-lg shadow-navy/20 backdrop-blur-xl'
          : 'bg-transparent py-5'
      }`}
    >
      <nav className="container-x flex items-center justify-between">
        <a
          href="#home"
          className="font-grotesk text-lg font-bold tracking-tight text-white"
          aria-label={`${profile.name} — home`}
        >
          <span className="text-electric-light">Z</span>ohaib
          <span className="text-electric-light">.</span>
        </a>

        {/* Desktop nav */}
        <ul className="hidden items-center gap-1 lg:flex">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className={`rounded-full px-3.5 py-2 text-sm font-medium transition-colors duration-200 ${
                  active === link.href
                    ? 'bg-white/10 text-white'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden lg:block">
          <a href="#contact" className="btn-primary !py-2.5 !px-5 text-xs">
            <Icon name="Send" className="h-3.5 w-3.5" />
            Let's Talk
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          onClick={() => setOpen((v) => !v)}
          className="inline-flex items-center justify-center rounded-xl p-2 text-white transition hover:bg-white/10 lg:hidden"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
        >
          <Icon name={open ? 'X' : 'Menu'} className="h-6 w-6" />
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden transition-[max-height,opacity] duration-300 lg:hidden ${
          open ? 'max-h-[640px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <ul className="container-x mt-3 flex flex-col gap-1 rounded-2xl bg-navy-deep/95 p-4 backdrop-blur-xl">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={close}
                className={`block rounded-xl px-4 py-3 text-sm font-medium transition-colors ${
                  active === link.href
                    ? 'bg-electric text-white'
                    : 'text-white/80 hover:bg-white/10'
                }`}
              >
                {link.label}
              </a>
            </li>
          ))}
          <li className="mt-2">
            <a href="#contact" onClick={close} className="btn-primary w-full">
              <Icon name="Send" className="h-4 w-4" />
              Let's Talk
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
