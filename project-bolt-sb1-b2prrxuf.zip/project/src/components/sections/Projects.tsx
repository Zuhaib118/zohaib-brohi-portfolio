import { projects } from '@/data/portfolio';
import { Icon } from '@/components/Icon';
import { SectionHeader } from '@/components/SectionHeader';
import { useScrollReveal } from '@/hooks/useScrollReveal';

export function Projects() {
  const ref = useScrollReveal<HTMLDivElement>();

  return (
    <section id="projects" className="section-pad bg-slate-50">
      <div ref={ref} className="container-x">
        <SectionHeader
          eyebrow="Projects"
          title={
            <>
              Things I've <span className="heading-gradient">built</span>
            </>
          }
          description="Real projects spanning showrooms, restaurants, e-commerce and education."
        />

        <div className="mt-14 grid gap-7 sm:grid-cols-2">
          {projects.map((project, i) => (
            <article
              key={project.title}
              className="card group overflow-hidden reveal hover:-translate-y-2 hover:border-electric/40 hover:shadow-card"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              {/* image */}
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={project.image}
                  alt={`${project.title} preview`}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/80 via-navy-deep/10 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <h3 className="font-grotesk text-xl font-bold text-white">{project.title}</h3>
                  <p className="mt-0.5 text-sm font-medium text-white/70">{project.subtitle}</p>
                </div>
              </div>

              {/* body */}
              <div className="p-6">
                <p className="text-sm leading-relaxed text-slate-600">{project.description}</p>

                <div className="mt-4">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Tech Stack</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {project.tech.map((t) => (
                      <span key={t} className="chip">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap gap-3">
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary !px-5 !py-2.5 text-xs"
                  >
                    <Icon name="ExternalLink" className="h-3.5 w-3.5" />
                    Live Demo
                  </a>
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary !px-5 !py-2.5 text-xs"
                  >
                    <Icon name="Github" className="h-3.5 w-3.5" />
                    GitHub Source
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
