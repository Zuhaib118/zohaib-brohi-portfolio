import { experience, services } from '@/data/portfolio';
import { Icon } from '@/components/Icon';
import { SectionHeader } from '@/components/SectionHeader';
import { useScrollReveal } from '@/hooks/useScrollReveal';

export function Experience() {
  const ref = useScrollReveal<HTMLDivElement>();

  return (
    <section id="experience" className="section-pad bg-white">
      <div ref={ref} className="container-x">
        <SectionHeader
          eyebrow="Experience & Services"
          title={
            <>
              Freelance <span className="heading-gradient">work & offerings</span>
            </>
          }
          description="Professional experience and the services I offer to clients."
        />

        {/* services grid */}
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <div
              key={s.title}
              className="card group flex items-start gap-4 p-6 reveal hover:-translate-y-1 hover:border-electric/40 hover:shadow-card"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-electric/10 text-electric transition-colors group-hover:bg-electric group-hover:text-white">
                <Icon name={s.icon} className="h-5 w-5" />
              </span>
              <div>
                <h3 className="font-grotesk text-base font-bold text-navy">{s.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-slate-600">{s.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* experience timeline */}
        <div className="mx-auto mt-16 max-w-3xl">
          <h3 className="mb-6 text-center font-grotesk text-xl font-bold text-navy reveal">
            Work History
          </h3>
          <ol className="relative space-y-8 before:absolute before:left-[19px] before:top-2 before:bottom-2 before:w-px before:bg-gradient-to-b before:from-electric before:via-electric/40 before:to-transparent">
            {experience.map((exp, i) => (
              <li
                key={i}
                className="relative pl-14 reveal"
                style={{ transitionDelay: `${i * 120}ms` }}
              >
                <span className="absolute left-0 top-1 inline-flex h-10 w-10 items-center justify-center rounded-full border-4 border-white bg-navy text-white shadow-md">
                  <Icon name="Briefcase" className="h-4 w-4" />
                </span>

                <div className="card p-6 hover:-translate-y-1 hover:border-electric/40 hover:shadow-card">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h4 className="font-grotesk text-lg font-bold text-navy">{exp.role}</h4>
                      <p className="mt-0.5 text-sm font-medium text-slate-600">{exp.company}</p>
                    </div>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-electric/10 px-3 py-1 text-xs font-bold text-electric">
                      <Icon name="Calendar" className="h-3 w-3" />
                      {exp.period}
                    </span>
                  </div>

                  <p className="mt-3 text-sm leading-relaxed text-slate-600">{exp.description}</p>

                  <div className="mt-4">
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Responsibilities & Services
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {exp.services.map((s) => (
                        <span key={s} className="chip">
                          <Icon name="CheckCircle2" className="h-3 w-3 text-electric" />
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ol>

          <p className="mt-6 rounded-2xl bg-slate-50 px-5 py-4 text-center text-xs text-slate-400 reveal">
            Experience details, dates and results are editable placeholders. Update them with
            verified information only.
          </p>
        </div>
      </div>
    </section>
  );
}
