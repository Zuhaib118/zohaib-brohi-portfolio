import { skillCategories } from '@/data/portfolio';
import { Icon } from '@/components/Icon';
import { SectionHeader } from '@/components/SectionHeader';
import { useScrollReveal } from '@/hooks/useScrollReveal';

export function Skills() {
  const ref = useScrollReveal<HTMLDivElement>();

  return (
    <section id="skills" className="section-pad bg-white">
      <div ref={ref} className="container-x">
        <SectionHeader
          eyebrow="Skills"
          title={
            <>
              What I <span className="heading-gradient">work with</span>
            </>
          }
          description="Tools and technologies I use across web development, marketing and design."
        />

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {skillCategories.map((cat, i) => (
            <div
              key={cat.title}
              className="card group relative overflow-hidden p-6 reveal hover:-translate-y-2 hover:border-electric/40 hover:shadow-card"
              style={{ transitionDelay: `${i * 90}ms` }}
            >
              <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-electric/5 transition-transform duration-500 group-hover:scale-150" aria-hidden />
              <span className="relative inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-navy text-white shadow-md transition-transform duration-300 group-hover:scale-110 group-hover:bg-electric">
                <Icon name={cat.icon} className="h-5 w-5" />
              </span>
              <h3 className="relative mt-5 font-grotesk text-lg font-bold text-navy">{cat.title}</h3>
              <ul className="relative mt-3 space-y-2">
                {cat.skills.map((skill) => (
                  <li
                    key={skill}
                    className="flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 text-sm font-medium text-slate-700 transition-colors group-hover:bg-white"
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-electric" />
                    {skill}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
