import { education } from '@/data/portfolio';
import { Icon } from '@/components/Icon';
import { SectionHeader } from '@/components/SectionHeader';
import { useScrollReveal } from '@/hooks/useScrollReveal';

export function Education() {
  const ref = useScrollReveal<HTMLDivElement>();

  return (
    <section id="education" className="section-pad bg-slate-50">
      <div ref={ref} className="container-x">
        <SectionHeader
          eyebrow="Education"
          title={
            <>
              My <span className="heading-gradient">academic journey</span>
            </>
          }
          description="The degrees, institutions and projects shaping my path."
        />

        <div className="mx-auto mt-14 max-w-3xl">
          <ol className="relative space-y-8 before:absolute before:left-[19px] before:top-2 before:bottom-2 before:w-px before:bg-gradient-to-b before:from-electric before:via-electric/40 before:to-transparent">
            {education.map((item, i) => (
              <li
                key={i}
                className="relative pl-14 reveal"
                style={{ transitionDelay: `${i * 120}ms` }}
              >
                <span className="absolute left-0 top-1 inline-flex h-10 w-10 items-center justify-center rounded-full border-4 border-slate-50 bg-navy text-white shadow-md">
                  <Icon name="GraduationCap" className="h-4 w-4" />
                </span>

                <div className="card p-6 hover:-translate-y-1 hover:border-electric/40 hover:shadow-card">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="font-grotesk text-lg font-bold text-navy">{item.degree}</h3>
                      <p className="mt-1 flex items-center gap-1.5 text-sm font-medium text-slate-600">
                        <Icon name="Building2" className="h-4 w-4 text-electric" />
                        {item.institution}
                      </p>
                    </div>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-electric/10 px-3 py-1 text-xs font-bold text-electric">
                      <Icon name="Calendar" className="h-3 w-3" />
                      {item.period}
                    </span>
                  </div>

                  <p className="mt-4 text-sm font-semibold text-slate-700">
                    Status:{' '}
                    <span className="font-normal text-slate-500">{item.current}</span>
                  </p>

                  <div className="mt-4">
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Relevant Academic Projects
                    </p>
                    <ul className="mt-2 space-y-1.5">
                      {item.projects.map((p, j) => (
                        <li key={j} className="flex items-start gap-2 text-sm text-slate-600">
                          <Icon name="ArrowRight" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-electric" />
                          {p}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
