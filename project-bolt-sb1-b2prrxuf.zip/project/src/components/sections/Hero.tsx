import { profile, socials } from '@/data/portfolio';
import { Icon } from '@/components/Icon';

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-navy pt-32 pb-24 sm:pt-40 lg:pt-44 lg:pb-32">
      {/* gradient + grid backdrop */}
      <div className="absolute inset-0 bg-gradient-to-br from-navy-deep via-navy to-navy-light" aria-hidden />
      <div className="absolute inset-0 hero-grid opacity-60" aria-hidden />
      <div className="absolute -top-32 -right-32 h-96 w-96 rounded-full bg-electric/30 blur-[120px]" aria-hidden />
      <div className="absolute -bottom-40 -left-20 h-96 w-96 rounded-full bg-electric/20 blur-[120px]" aria-hidden />

      <div className="container-x relative grid items-center gap-12 lg:grid-cols-[1.3fr_1fr]">
        {/* Text */}
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-electric-light backdrop-blur">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-electric-light opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-electric-light" />
            </span>
            Available for opportunities
          </span>

          <h1 className="mt-6 font-grotesk text-4xl font-bold leading-[1.05] text-white sm:text-5xl lg:text-6xl text-balance">
            Hi, I'm {profile.name.split(' ')[0]}{' '}
            <span className="bg-gradient-to-r from-electric-light via-electric to-electric-dark bg-clip-text text-transparent">
              Brohi
            </span>
          </h1>

          <p className="mt-4 font-grotesk text-lg font-semibold text-white/90 sm:text-xl">
            {profile.title}
          </p>

          <p className="mt-5 max-w-xl text-base leading-relaxed text-white/70 sm:text-lg text-balance">
            {profile.tagline}
          </p>

          <div className="mt-9 flex flex-wrap gap-3">
            <a href="#projects" className="btn-primary">
              <Icon name="ArrowUpRight" className="h-4 w-4" />
              View My Projects
            </a>
            <a href="#certificates" className="btn-ghost border border-white/20">
              <Icon name="Award" className="h-4 w-4" />
              Explore My Certificates
            </a>
            <a href="#contact" className="btn-ghost border border-white/20">
              <Icon name="Mail" className="h-4 w-4" />
              Contact Me
            </a>
          </div>

          {/* social row */}
          <div className="mt-9 flex items-center gap-4">
            <span className="text-xs font-medium uppercase tracking-widest text-white/40">
              Connect
            </span>
            <div className="h-px flex-1 max-w-[60px] bg-white/15" />
            <div className="flex items-center gap-3">
              <SocialLink href={socials.github} icon="Github" label="GitHub" />
              <SocialLink href={socials.linkedin} icon="Linkedin" label="LinkedIn" />
              <SocialLink href={socials.fiverr} icon="Briefcase" label="Fiverr" />
              <SocialLink href={socials.email} icon="Mail" label="Email" />
            </div>
          </div>
        </div>

        {/* Profile photo */}
        <div className="relative mx-auto w-full max-w-sm animate-fade-in lg:max-w-none">
          <div className="relative">
            <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-tr from-electric/40 via-transparent to-electric-light/30 blur-2xl" aria-hidden />
            <div className="absolute inset-0 rounded-[2rem] border border-white/10" aria-hidden />
            <div className="relative overflow-hidden rounded-[2rem] border-2 border-white/15 shadow-2xl shadow-navy-deep/50">
              <img
                src={profile.photo}
                alt={`Portrait of ${profile.name}`}
                className="aspect-[4/5] w-full object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/70 via-transparent to-transparent" />
            </div>

            {/* floating badge */}
            <div className="absolute -bottom-5 -left-5 rounded-2xl border border-white/15 bg-navy-light/90 px-5 py-4 shadow-glow backdrop-blur-md">
              <p className="font-grotesk text-sm font-bold text-white">BSIT Student</p>
              <p className="mt-0.5 text-xs text-white/60">{profile.university}</p>
            </div>
          </div>
        </div>
      </div>

      {/* scroll cue */}
      <a
        href="#about"
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-1 text-white/50 transition hover:text-white sm:flex"
        aria-label="Scroll to about section"
      >
        <span className="text-[10px] uppercase tracking-widest">Scroll</span>
        <Icon name="ArrowRight" className="h-4 w-4 rotate-90 animate-bounce" />
      </a>
    </section>
  );
}

function SocialLink({
  href,
  icon,
  label,
}: {
  href: string;
  icon: string;
  label: string;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/5 text-white/80 transition-all duration-300 hover:-translate-y-0.5 hover:border-electric hover:bg-electric hover:text-white"
    >
      <Icon name={icon} className="h-4 w-4" />
    </a>
  );
}
