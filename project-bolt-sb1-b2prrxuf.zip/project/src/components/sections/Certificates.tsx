import { certificates } from '@/data/portfolio';
import { Icon } from '@/components/Icon';
import { SectionHeader } from '@/components/SectionHeader';
import { useScrollReveal } from '@/hooks/useScrollReveal';

export function Certificates() {
  const ref = useScrollReveal<HTMLDivElement>();

  return (
    <section id="certificates" className="section-pad bg-white">
      <div ref={ref} className="container-x">
        <SectionHeader
          eyebrow="Certificates"
          title={
            <>
              Courses & <span className="heading-gradient">certifications</span>
            </>
          }
          description="Verified courses that back up my skills. More to be added as I complete them."
        />

        <div className="mt-14 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
          {certificates.map((cert, i) => (
            <article
              key={i}
              className="card group flex flex-col overflow-hidden reveal hover:-translate-y-2 hover:border-electric/40 hover:shadow-card"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              {/* preview */}
              <div className="relative aspect-[4/3] overflow-hidden bg-gradient-to-br from-navy to-navy-light">
                {cert.image ? (
                  <img
                    src={cert.image}
                    alt={`${cert.title} certificate preview`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                ) : (
                  <div className="flex h-full w-full flex-col items-center justify-center gap-3 px-6 text-center">
                    <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-white/10 text-electric-light">
                      <Icon name="Award" className="h-6 w-6" />
                    </span>
                    <p className="text-xs font-medium text-white/60">
                      Add certificate preview image
                    </p>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/60 to-transparent" />
              </div>

              {/* body */}
              <div className="flex flex-1 flex-col p-6">
                <h3 className="font-grotesk text-lg font-bold leading-snug text-navy">
                  {cert.title}
                </h3>
                <p className="mt-1.5 flex items-center gap-1.5 text-sm font-medium text-slate-600">
                  <Icon name="Building2" className="h-4 w-4 text-electric" />
                  {cert.organization}
                </p>
                <p className="mt-1 flex items-center gap-1.5 text-xs text-slate-400">
                  <Icon name="Calendar" className="h-3.5 w-3.5" />
                  {cert.date}
                </p>

                <div className="mt-4">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Skills Learned
                  </p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {cert.skills.map((s) => (
                      <span key={s} className="chip">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-auto pt-6">
                  <a
                    href={cert.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary w-full !px-5 !py-2.5 text-xs"
                  >
                    <Icon name="ExternalLink" className="h-3.5 w-3.5" />
                    View Certificate
                  </a>
                </div>
              </div>
            </article>
          ))}

          {/* add-more prompt card */}
          <div className="flex flex-col items-center justify-center rounded-3xl border-2 border-dashed border-slate-200 bg-slate-50/50 p-8 text-center reveal">
            <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
              <Icon name="Award" className="h-6 w-6" />
            </span>
            <p className="mt-4 font-grotesk text-base font-bold text-navy">More on the way</p>
            <p className="mt-1 text-sm text-slate-500">
              New certificates will be added here as they are earned.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
