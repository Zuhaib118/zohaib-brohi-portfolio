import { useState, type FormEvent } from 'react';
import { profile, socials } from '@/data/portfolio';
import { Icon } from '@/components/Icon';
import { SectionHeader } from '@/components/SectionHeader';
import { useScrollReveal } from '@/hooks/useScrollReveal';

interface FormState {
  name: string;
  email: string;
  message: string;
}

const initial: FormState = { name: '', email: '', message: '' };

export function Contact() {
  const ref = useScrollReveal<HTMLDivElement>();
  const [form, setForm] = useState<FormState>(initial);
  const [errors, setErrors] = useState<Partial<FormState>>({});
  const [status, setStatus] = useState<'idle' | 'submitted'>('idle');

  function validate(): boolean {
    const next: Partial<FormState> = {};
    if (!form.name.trim()) next.name = 'Please enter your name';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = 'Enter a valid email';
    if (form.message.trim().length < 10) next.message = 'Message must be at least 10 characters';
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    // The form needs a backend or email service to deliver messages.
    // Wire this up to an edge function, Formspree, EmailJS, etc.
    setStatus('submitted');
    setForm(initial);
  }

  function update<K extends keyof FormState>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
    if (errors[key]) setErrors((p) => ({ ...p, [key]: undefined }));
  }

  const contactLinks = [
    { icon: 'Mail', label: 'Email', value: 'your.email@example.com', href: socials.email },
    { icon: 'Github', label: 'GitHub', value: 'github.com/yourusername', href: socials.github },
    { icon: 'Linkedin', label: 'LinkedIn', value: 'linkedin.com/in/yourprofile', href: socials.linkedin },
    { icon: 'Briefcase', label: 'Fiverr', value: 'fiverr.com/yourprofile', href: socials.fiverr },
  ];

  return (
    <section id="contact" className="section-pad bg-slate-50">
      <div ref={ref} className="container-x">
        <SectionHeader
          eyebrow="Contact"
          title={
            <>
              Let's <span className="heading-gradient">work together</span>
            </>
          }
          description="Have a project, question or opportunity? I'd love to hear from you."
        />

        <div className="mt-14 grid gap-8 lg:grid-cols-[1fr_1.3fr]">
          {/* contact info */}
          <div className="reveal space-y-4">
            {contactLinks.map((c) => (
              <a
                key={c.label}
                href={c.href}
                target="_blank"
                rel="noopener noreferrer"
                className="card group flex items-center gap-4 p-5 hover:-translate-y-1 hover:border-electric/40 hover:shadow-card"
              >
                <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-navy text-white transition-colors group-hover:bg-electric">
                  <Icon name={c.icon} className="h-5 w-5" />
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    {c.label}
                  </p>
                  <p className="truncate text-sm font-semibold text-navy">{c.value}</p>
                </div>
                <Icon name="ArrowUpRight" className="ml-auto h-4 w-4 text-slate-300 transition-colors group-hover:text-electric" />
              </a>
            ))}

            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs leading-relaxed text-amber-800">
              <strong className="font-bold">Note:</strong> The contact form below needs a backend or
              email service to deliver messages. Until connected, it validates input but does not send.
            </div>
          </div>

          {/* form */}
          <form
            onSubmit={handleSubmit}
            noValidate
            className="card reveal space-y-5 p-7 sm:p-8"
          >
            {status === 'submitted' && (
              <div className="flex items-center gap-3 rounded-2xl border border-green-200 bg-green-50 p-4 text-sm font-medium text-green-800">
                <Icon name="CheckCircle2" className="h-5 w-5 shrink-0" />
                Thanks! Your message has been recorded. (Connect a backend to actually deliver it.)
              </div>
            )}

            <Field
              label="Your Name"
              error={errors.name}
            >
              <input
                type="text"
                value={form.name}
                onChange={(e) => update('name', e.target.value)}
                placeholder="John Doe"
                aria-invalid={!!errors.name}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-navy outline-none transition focus:border-electric focus:bg-white focus:ring-4 focus:ring-electric/15"
              />
            </Field>

            <Field label="Email Address" error={errors.email}>
              <input
                type="email"
                value={form.email}
                onChange={(e) => update('email', e.target.value)}
                placeholder="john@example.com"
                aria-invalid={!!errors.email}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-navy outline-none transition focus:border-electric focus:bg-white focus:ring-4 focus:ring-electric/15"
              />
            </Field>

            <Field label="Message" error={errors.message}>
              <textarea
                value={form.message}
                onChange={(e) => update('message', e.target.value)}
                placeholder="Tell me about your project..."
                rows={5}
                aria-invalid={!!errors.message}
                className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-navy outline-none transition focus:border-electric focus:bg-white focus:ring-4 focus:ring-electric/15"
              />
            </Field>

            <button type="submit" className="btn-primary w-full">
              <Icon name="Send" className="h-4 w-4" />
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-semibold text-navy">{label}</label>
      {children}
      {error && <p className="mt-1.5 text-xs font-medium text-red-500">{error}</p>}
    </div>
  );
}
