import { profile, socials, navLinks } from '@/data/portfolio';
import { Icon } from '@/components/Icon';

export function Footer() {
  const year = new Date().getFullYear();

  const socialLinks = [
    { icon: 'Github', href: socials.github, label: 'GitHub' },
    { icon: 'Linkedin', href: socials.linkedin, label: 'LinkedIn' },
    { icon: 'Briefcase', href: socials.fiverr, label: 'Fiverr' },
    { icon: 'Mail', href: socials.email, label: 'Email' },
  ];

  return (
    <footer className="relative overflow-hidden bg-navy-deep pt-16 pb-8">
      <div className="absolute -top-24 left-1/2 h-48 w-[40rem] -translate-x-1/2 rounded-full bg-electric/20 blur-[120px]" aria-hidden />

      <div className="container-x relative">
        <div className="grid gap-10 lg:grid-cols-[1.5fr_1fr_1fr]">
          {/* brand */}
          <div>
            <a href="#home" className="font-grotesk text-xl font-bold text-white">
              <span className="text-electric-light">Z</span>ohaib Brohi
            </a>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-white/60">
              {profile.title}
            </p>
            <p className="mt-2 max-w-xs text-sm leading-relaxed text-white/50">
              {profile.tagline}
            </p>

            <div className="mt-5 flex gap-3">
              {socialLinks.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.label}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/5 text-white/70 transition-all duration-300 hover:-translate-y-0.5 hover:border-electric hover:bg-electric hover:text-white"
                >
                  <Icon name={s.icon} className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* quick links */}
          <div>
            <h4 className="font-grotesk text-sm font-bold uppercase tracking-wider text-white">
              Navigate
            </h4>
            <ul className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2.5">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-white/60 transition-colors hover:text-electric-light"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* contact */}
          <div>
            <h4 className="font-grotesk text-sm font-bold uppercase tracking-wider text-white">
              Get in touch
            </h4>
            <ul className="mt-4 space-y-3 text-sm text-white/60">
              <li className="flex items-center gap-2">
                <Icon name="MapPin" className="h-4 w-4 text-electric-light" />
                {profile.location}
              </li>
              <li>
                <a
                  href={socials.email}
                  className="flex items-center gap-2 transition-colors hover:text-electric-light"
                >
                  <Icon name="Mail" className="h-4 w-4 text-electric-light" />
                  Email me
                </a>
              </li>
              <li>
                <a
                  href={socials.fiverr}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 transition-colors hover:text-electric-light"
                >
                  <Icon name="Briefcase" className="h-4 w-4 text-electric-light" />
                  Hire on Fiverr
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 sm:flex-row">
          <p className="text-xs text-white/50">
            &copy; {year} {profile.name}. All rights reserved.
          </p>
          <p className="text-xs text-white/40">
            Built with React, TypeScript &amp; Tailwind CSS.
          </p>
        </div>
      </div>
    </footer>
  );
}
