import { achievements } from '@/data/portfolio';
import { Icon } from '@/components/Icon';
import { SectionHeader } from '@/components/SectionHeader';
import { useScrollReveal } from '@/hooks/useScrollReveal';

export function Achievements() {
  const ref = useScrollReveal<HTMLDivElement>();

  return (
    <section id="achievements" className="section-pad bg-slate-50">
      <div ref={ref} className="container-x">
        <SectionHeader
          eyebrow="Achievements"
          title={
            <>
              Milestones & <span className="heading-gradient">accomplishments</span>
            </>
          }
          description="Academic achievements, training, presentations, competitions, awards and verified freelance results."
        />

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {achievements.map((item, i) => (
            <article
              key={i}
              className="card group flex gap-5 p-6 reveal hover:-translate-y-1 hover:border-electric/40 hover:shadow-card"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              {item.image ? (
                <img
                  src={item.image}
                  alt={item.title}
                  loading="lazy"
                  className="h-24 w-24 shrink-0 rounded-2xl object-cover"
                />
              ) : (
                <span className="inline-flex h-24 w-24 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-navy to-navy-light text-electric-light">
                  <Icon name="Award" className="h-8 w-8" />
                </span>
              )}

              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-electric/10 px-2.5 py-1 text-xs font-bold text-electric">
                    <Icon name="CheckCircle2" className="h-3 w-3" />
                    {item.date}
                  </span>
                </div>
                <h3 className="mt-3 font-grotesk text-lg font-bold leading-snug text-navy">
                  {item.title}
                </h3>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-600">
                  {item.description}
                </p>
              </div>
            </article>
          ))}

          <div className="flex flex-col items-center justify-center rounded-3xl border-2 border-dashed border-slate-200 bg-white p-8 text-center reveal md:col-span-2">
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
              <Icon name="Sparkles" className="h-5 w-5" />
            </span>
            <p className="mt-3 text-sm text-slate-500">
              Edit the data file to add real achievements, awards and verified freelance
              accomplishments. Avoid inventing details.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
