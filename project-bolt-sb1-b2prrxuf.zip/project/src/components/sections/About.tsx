import { profile } from '@/data/portfolio';
import { Icon } from '@/components/Icon';
import { SectionHeader } from '@/components/SectionHeader';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const stats = [
  { label: 'Projects Built', value: '4+', icon: 'Clapperboard' },
  { label: 'Focus Areas', value: '2', icon: 'Sparkles' },
  { label: 'University', value: 'BSIT', icon: 'GraduationCap' },
];

export function About() {
  const ref = useScrollReveal<HTMLDivElement>();

  return (
    <section id="about" className="section-pad bg-white">
      <div ref={ref} className="container-x">
        <SectionHeader
          eyebrow="About Me"
          title={
            <>
              Getting to know <span className="heading-gradient">Zohaib</span>
            </>
          }
          description="A student-developer building real things while learning."
        />

        <div className="mt-14 grid gap-10 lg:grid-cols-[1.5fr_1fr] lg:gap-16">
          {/* narrative */}
          <div className="reveal">
            <div className="space-y-5 text-base leading-relaxed text-slate-600 sm:text-[1.05rem]">
              {profile.about.map((para, i) => (
                <p key={i}>{para}</p>
              ))}
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <InfoChip icon="MapPin" text={profile.location} />
              <InfoChip icon="GraduationCap" text={profile.university} />
            </div>

            {profile.resumeUrl ? (
              <a href={profile.resumeUrl} download className="btn-primary mt-8" aria-label="Download resume">
                <Icon name="Download" className="h-4 w-4" />
                Download Resume
              </a>
            ) : (
              <div className="mt-8 inline-flex items-center gap-2 rounded-full border border-dashed border-slate-300 bg-slate-50 px-4 py-2.5 text-sm text-slate-500">
                <Icon name="FileText" className="h-4 w-4" />
                Resume file link will appear here once provided
              </div>
            )}
          </div>

          {/* stats card */}
          <div className="reveal grid grid-cols-1 gap-4 sm:grid-cols-3 lg:grid-cols-1">
            {stats.map((s) => (
              <div
                key={s.label}
                className="card group flex items-center gap-4 p-6 hover:-translate-y-1 hover:border-electric/40 hover:shadow-card"
              >
                <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-electric/10 text-electric transition-colors group-hover:bg-electric group-hover:text-white">
                  <Icon name={s.icon} className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-grotesk text-2xl font-bold text-navy">{s.value}</p>
                  <p className="text-sm text-slate-500">{s.label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function InfoChip({ icon, text }: { icon: string; text: string }) {
  return (
    <span className="chip">
      <Icon name={icon} className="h-3.5 w-3.5 text-electric" />
      {text}
    </span>
  );
}
