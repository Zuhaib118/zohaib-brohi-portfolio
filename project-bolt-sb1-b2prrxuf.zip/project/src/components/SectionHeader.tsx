import type { ReactNode } from 'react';

interface SectionHeaderProps {
  eyebrow: string;
  title: ReactNode;
  description?: string;
  align?: 'left' | 'center';
}

export function SectionHeader({
  eyebrow,
  title,
  description,
  align = 'center',
}: SectionHeaderProps) {
  const alignment = align === 'center' ? 'items-center text-center' : 'items-start text-left';
  return (
    <div className={`flex flex-col ${alignment} reveal`}>
      <span className="mb-3 inline-flex items-center gap-2 rounded-full bg-electric/10 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.18em] text-electric">
        {eyebrow}
      </span>
      <h2 className="font-grotesk text-3xl font-bold leading-tight text-navy sm:text-4xl lg:text-[2.75rem] text-balance">
        {title}
      </h2>
      {description && (
        <p
          className={`mt-4 max-w-2xl text-base leading-relaxed text-slate-600 ${
            align === 'center' ? 'mx-auto' : ''
          }`}
        >
          {description}
        </p>
      )}
    </div>
  );
}
