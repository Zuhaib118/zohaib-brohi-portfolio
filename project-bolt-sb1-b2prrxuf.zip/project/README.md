# Zohaib Brohi — Personal Portfolio

A premium, fully responsive personal portfolio website for **Zohaib Brohi**, a BS Information Technology student, web developer and digital marketer.

Built with **React**, **TypeScript**, **Vite** and **Tailwind CSS**.

---

## Features

- Sophisticated navy blue, white and electric blue gradient theme
- Smooth scrolling and subtle scroll-reveal animations
- Fully responsive — mobile, tablet and desktop
- SEO metadata and social share tags
- Accessibility: semantic HTML, ARIA labels, keyboard-friendly, reduced-motion support
- Central, editable data file — update all content in one place

### Sections

1. **Hero** — name, title, tagline, CTA buttons, profile photo, social links
2. **About** — professional introduction, stats, resume button
3. **Education** — editable timeline with degree, institution, period, status and projects
4. **Skills** — categorized skills (no misleading proficiency percentages)
5. **Projects** — four editable project cards with image, tech stack, Live Demo & GitHub buttons
   - AutoVerse (Zamil's Car Gallery)
   - Zayka House (Zobro Restaurant)
   - TechNova (Electronics E-commerce)
   - EduConnect (Education Portal)
6. **Certificates** — gallery with preview, title, organization, date, skills and View button
   - PITP Digital Marketing course entry included
   - Placeholders for additional genuine certificates
7. **Achievements** — academic, training, presentations, competitions, awards, verified freelance results
8. **Experience & Services** — freelance work history and services offered
9. **Contact** — validated form (note: needs a backend/email service to deliver), plus email, GitHub, LinkedIn and Fiverr links
10. **Footer** — social links, quick navigation, copyright

---

## Getting Started

### Prerequisites

- Node.js 18+ and npm

### Install & run

```bash
npm install
npm run dev
```

The site runs locally on the Vite dev server.

### Build for production

```bash
npm run build
npm run preview
```

### Type checking & linting

```bash
npm run typecheck
npm run lint
```

---

## How to edit your content

**All content lives in one file:** [`src/data/portfolio.ts`](src/data/portfolio.ts).

Open that file to edit:

- Your name, title, tagline, profile photo and about text
- Social links (GitHub, LinkedIn, Fiverr, email)
- Education entries
- Skills and skill categories
- Projects (title, description, image, tech stack, live & GitHub URLs)
- Certificates (title, organization, date, skills, preview image, link)
- Achievements (title, description, date, optional image)
- Experience / freelance history and services
- Resume download link

To **add** a new project, certificate or achievement, copy an existing object in the relevant array and edit the fields. To **remove** one, delete the object.

### Replacing the profile photo

In `src/data/portfolio.ts`, set `profile.photo` to a URL or a path to a local file placed in the `public/` folder, e.g. `"/my-photo.jpg"`.

### Connecting the contact form

The contact form validates input on the client but does **not** send messages by default. To deliver messages, connect it to a backend or email service such as:

- [Formspree](https://formspree.io)
- [EmailJS](https://www.emailjs.com)
- A Supabase Edge Function
- Any API endpoint you control

The form handler is in [`src/components/sections/Contact.tsx`](src/components/sections/Contact.tsx) — replace the `handleSubmit` logic with your delivery mechanism.

### Adding your resume

Place your resume PDF in the `public/` folder (e.g. `public/resume.pdf`) and set `profile.resumeUrl` in the data file to `"/resume.pdf"`. The "Download Resume" button will appear automatically.

---

## Tech stack

| Tool | Purpose |
| --- | --- |
| React 18 | UI library |
| TypeScript | Type safety |
| Vite | Build tool & dev server |
| Tailwind CSS | Styling |
| lucide-react | Icons |

---

## Project structure

```
src/
├── components/
│   ├── Icon.tsx              # Centralized icon helper
│   ├── Navbar.tsx            # Sticky responsive navigation
│   ├── SectionHeader.tsx     # Reusable section heading
│   └── sections/
│       ├── Hero.tsx
│       ├── About.tsx
│       ├── Education.tsx
│       ├── Skills.tsx
│       ├── Projects.tsx
│       ├── Certificates.tsx
│       ├── Achievements.tsx
│       ├── Experience.tsx
│       ├── Contact.tsx
│       └── Footer.tsx
├── data/
│   └── portfolio.ts          # ← EDIT ALL CONTENT HERE
├── hooks/
│   └── useScrollReveal.ts    # Scroll animation hook
├── App.tsx
├── main.tsx
└── index.css
```

---

## License

Personal portfolio for Zohaib Brohi. All content is editable and owned by the author.
