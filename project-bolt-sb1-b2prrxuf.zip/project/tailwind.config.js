/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#0a1a3f',
          light: '#13265c',
          deep: '#050f29',
        },
        electric: {
          DEFAULT: '#1e63ff',
          dark: '#1650db',
          light: '#4d8bff',
        },
      },
      fontFamily: {
        jakarta: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        grotesk: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        glow: '0 0 40px -10px rgba(30, 99, 255, 0.5)',
        card: '0 10px 40px -12px rgba(10, 26, 63, 0.18)',
      },
    },
  },
  plugins: [],
};
